<?php

use App\Enums\OrderType;

return [
    OrderType::DELIVERY => 'ڈلیوری',
    OrderType::PICK_UP => 'پک اپ',
    OrderType::POS      => 'پوز',
];
