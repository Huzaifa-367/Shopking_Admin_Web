<?php

use App\Enums\PromotionType;

return [
    PromotionType::SMALL   => 'چھوٹا',
    PromotionType::BIG => 'بڑا',
];
