<?php

use App\Enums\Source;

return [
    Source::WEB => 'Web',
    Source::APP => 'App',
    Source::POS => 'Pos',

];
