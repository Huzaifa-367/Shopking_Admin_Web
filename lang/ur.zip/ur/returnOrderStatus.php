<?php

use App\Enums\ReturnOrderStatus;

return [
    ReturnOrderStatus::PENDING  => 'Pending',
    ReturnOrderStatus::ACCEPT   => 'Accept',
    ReturnOrderStatus::REJECTED => 'Rejected',


];