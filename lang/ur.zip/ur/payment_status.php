<?php

use App\Enums\PaymentStatus;

return [
    PaymentStatus::PAID   => 'ادا شدہ',
    PaymentStatus::UNPAID => 'ادا نہیں شدہ',
];
