<?php

use App\Enums\Status;

return [
    Status::ACTIVE   => 'Active',
    Status::INACTIVE => 'Inactive',

];