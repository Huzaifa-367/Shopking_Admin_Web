<?php

use App\Enums\Ask;

return [
    Ask:: YES   => 'ہاں',
    Ask:: NO    => 'نہیں',
];
